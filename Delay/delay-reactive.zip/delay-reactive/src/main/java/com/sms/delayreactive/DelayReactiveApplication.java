package com.sms.delayreactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DelayReactiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(DelayReactiveApplication.class, args);
	}

}
