package com.sms.delaysynchronous;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DelaySynchronousApplicationTests {

	@Test
	void contextLoads() {
	}

}
