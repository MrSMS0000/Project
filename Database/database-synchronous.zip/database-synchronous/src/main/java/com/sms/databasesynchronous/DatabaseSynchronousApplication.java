package com.sms.databasesynchronous;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseSynchronousApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseSynchronousApplication.class, args);
	}

}
