package com.sms.databasesynchronous;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseSynchronousApplicationTests {

	@Test
	void contextLoads() {
	}

}
