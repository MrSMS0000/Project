package com.sms.databasereactive;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseReactiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseReactiveApplication.class, args);
	}

}
