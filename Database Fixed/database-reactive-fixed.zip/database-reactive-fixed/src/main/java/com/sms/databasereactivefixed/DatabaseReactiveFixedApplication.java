package com.sms.databasereactivefixed;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatabaseReactiveFixedApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatabaseReactiveFixedApplication.class, args);
	}

}
