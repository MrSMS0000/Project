package com.sms.databasereactivefixed;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatabaseReactiveFixedApplicationTests {

	@Test
	void contextLoads() {
	}

}
